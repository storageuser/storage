﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class navmeshtest : MonoBehaviour
{

    public Transform target;
    public int trigger_rush = 0;
    private int check = 0;

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.E))
        {
            if (check == 1)
            {
               
                check = 0;
            }
            else
            {
                
                check = 1;
            }
            


        }

        if (check == 1)
        {
            GetComponent<NavMeshAgent>().SetDestination(target.position);
        }
        /*  void OnTriggerEnter(Collider other)
          {
              if (other.transform.tag == "lol")
              {

              }
          }*/

        //if (trigger_rush == 1) {

        

        // }



    }

}
