﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

[RequireComponent(typeof(NavMeshAgent))]
public class test : MonoBehaviour {

    public float speed = 1f;
    float xm = 0; float ym = 0;
    public int speed_rotate = 5;
    public GameObject RAGE;
    public GameObject player;
    public int check = 0;

    void Update ()
    {
        


        xm = Mathf.Lerp(xm,Input.GetAxis("Horizontal"),Time.deltaTime * 8);
        ym = Mathf.Lerp(ym, Input.GetAxis("Vertical"), Time.deltaTime * 8);

        transform.Rotate(0, Input.GetAxis("Mouse X") * speed_rotate, 0);

        GetComponent<Animator>().SetFloat("X", xm);
        GetComponent<Animator>().SetFloat("Y", ym);

        if (Input.GetKeyDown(KeyCode.Space))
        {
            GetComponent<Animator>().Play("dance");
        }

        Vector3 move = new Vector3(xm,0,ym);
        move = transform.TransformDirection(move);
        move *= speed;

        GetComponent<NavMeshAgent>().Move(move);
    }
	
}
