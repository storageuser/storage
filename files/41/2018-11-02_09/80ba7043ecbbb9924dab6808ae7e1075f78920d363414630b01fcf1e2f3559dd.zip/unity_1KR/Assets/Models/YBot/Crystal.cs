﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Crystal : MonoBehaviour {

    public int n = 5;
    public UnityEngine.UI.Text score ;
    public GameObject door;
    


    void Update()
    {
        score.text = "Осталось кристаллов: " + n;
        if ((n == 0))
        {
            Destroy(door);
        }
    }

 


    public void OnTriggerEnter(Collider other)
    {
        
        if (other.gameObject.CompareTag("Alm"))
        {
            Destroy(other.gameObject);
            n -= 1;

            if ((other.gameObject.CompareTag("sten")))
            {
                Destroy(gameObject);
            }
        }
    }
    public void textnim()
    {

           
    }
    public void destroydoor()
    {

    }
    
}
