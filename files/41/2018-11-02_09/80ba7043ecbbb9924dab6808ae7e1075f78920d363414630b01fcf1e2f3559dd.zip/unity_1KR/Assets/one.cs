﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CharController : MonoBehaviour
{

    public float speed = 100;
    public float speed_rotate = 10;

    void Update()
    {
        if (Input.GetAxis("Vertical") != 0)
        {
            Vector3 direction = new Vector3(0, 0, Input.GetAxis("Vertical"));
            direction = transform.TransformDirection(direction);
            direction *= speed;

            GetComponent<Rigidbody>().AddForce(direction);
        }

        if (Input.GetKeyDown(KeyCode.W))
        {
            GetComponent<Animator>().Play("idle_to_run");
        }

        if (Input.GetKeyUp(KeyCode.W))
        {
            GetComponent<Animator>().Play("run_end");
        }

        transform.Rotate(0, Input.GetAxis("Mouse X") * speed_rotate, 0);
    }

}
